#!/usr/bin/env bash
set -euo pipefail

if [[ $# == 1 && ( $1 == --help || $1 == -h ) ]]; then
    echo 'Usage: sudo ./install.sh'
    echo 'Install all eight DEBs, enable the checker globally, and start it in active user sessions.'
    echo 'For ISO builds, run this script inside the target image chroot.'
    exit 0
fi
if [[ $# != 0 ]]; then
    echo 'Usage: sudo ./install.sh' >&2
    exit 2
fi

script=$(readlink -f -- "${BASH_SOURCE[0]}")
cd -- "$(dirname -- "$script")"
packages=(
    ./aos-welcome_1.0.8_all.deb
    ./aos-app-remover_2.2.0_all.deb
    ./aos-deb-installer_2.2.0_all.deb
    ./aos-update-manager_2.2.0_all.deb
    ./aos-windows-app-support_2.2.0_all.deb
    ./aosver_2.2.0_all.deb
    ./aos-gaming-center_1.0.8_all.deb
    ./aos-touch-keyboard_1.1.3_all.deb
)
for package in "${packages[@]}"; do
    if [[ ! -f $package ]]; then
        echo "Missing package: $package" >&2
        exit 1
    fi
done
sha256sum --check --strict <<'CHECKSUMS'
f27f7253bfeb2ee026015e0cdcae3ca0bb9015e075bb4104183f549e2ef59ba6  aos-welcome_1.0.8_all.deb
2d66dde2538e33fe1673988952aaee4f9c5200336eed149e154a1ab2ca29a82e  aos-touch-keyboard_1.1.3_all.deb
18d8719c182be37e30c997fd8fc5b01fe5b4fd1d89ac601f9bf50efafbef1e2a  aos-app-remover_2.2.0_all.deb
7fd1eef684ec9219f90af72c23699f2329097f3a7c68d6ca6f6925949f81ad34  aos-deb-installer_2.2.0_all.deb
d0e84380c34d4e1b06890cd146aa67a87f0530a9a869b7f2cab2f4a9a2d10677  aos-gaming-center_1.0.8_all.deb
508563840f03b6c73f668cbe2ada2bd5152a0930ed817644f166b8d3604bfd28  aos-update-manager_2.2.0_all.deb
c15b26624fe57f87738ddf08e628240aab5a35660b280411eecda7c9e6983410  aos-windows-app-support_2.2.0_all.deb
9d049225340a745b168b952097dbf53060b6f93f96160b80eb55793f0019631d  aosver_2.2.0_all.deb
CHECKSUMS

if [[ $(id -u) != 0 ]]; then
    exec sudo -- "$script"
fi

apt-get install --yes --no-remove "${packages[@]}"
systemctl --global unmask aos-update-checker.service
systemctl --global enable aos-update-checker.service

echo 'Installation complete. The update checker is enabled for all desktop users.'

# A chroot may share the host /run. Never start host services from an image build.
target_root=$(stat -Lc '%d:%i' /)
init_root=$(stat -Lc '%d:%i' /proc/1/root 2>/dev/null || true)
if [[ -z $init_root || $target_root != "$init_root" ]]; then
    echo 'Image/chroot detected: the checker will start at the next installed-system desktop login.'
    exit 0
fi

# Disable the previous automatic keyboard in the invoking desktop session.
if [[ -n ${SUDO_USER:-} && $SUDO_USER != root ]]; then
    keyboard_uid=$(id -u "$SUDO_USER")
    if [[ -S /run/user/$keyboard_uid/bus ]]; then
        keyboard_home=$(getent passwd "$SUDO_USER" | cut -d: -f6)
        runuser -u "$SUDO_USER" -- env HOME="$keyboard_home" XDG_RUNTIME_DIR="/run/user/$keyboard_uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$keyboard_uid/bus" /usr/bin/aos-touch-keyboard --disable-auto || echo 'Run aos-touch-keyboard --disable-auto in your desktop session.'
    fi
fi

read -r -a boot_args < /proc/cmdline || true
for arg in "${boot_args[@]}"; do
    case "$arg" in
        boot=casper|boot=live)
            echo 'Live session: startup is enabled for the installed system; the checker is not started here.'
            exit 0
            ;;
    esac
done
if [[ -e /run/casper || -e /run/live/medium || -e /run/live/rootfs ]]; then
    echo 'Live session: the checker will start after installation, at desktop login.'
    exit 0
fi

state=$(systemctl is-system-running 2>/dev/null || true)
case "$state" in
    running|degraded) ;;
    *) echo 'No running system manager: the checker will start at the next desktop login.'; exit 0 ;;
esac
if ! users=$(loginctl list-users --no-legend --no-pager); then
    echo 'Packages installed and startup enabled, but active sessions could not be queried.' >&2
    exit 1
fi

started=0
failed=0
while read -r uid user rest; do
    [[ $uid =~ ^[0-9]+$ && $uid != 0 && -n $user ]] || continue
    if ! runtime=$(loginctl show-user "$uid" --property=RuntimePath --value); then
        echo "Could not query the runtime directory for $user." >&2
        failed=1
        continue
    fi
    [[ -n $runtime && -S $runtime/bus ]] || continue
    user_command=(runuser -u "$user" -- env
        "XDG_RUNTIME_DIR=$runtime" "DBUS_SESSION_BUS_ADDRESS=unix:path=$runtime/bus"
        systemctl --user)
    if "${user_command[@]}" unmask aos-update-checker.service \
        && "${user_command[@]}" daemon-reload \
        && "${user_command[@]}" start aos-update-checker.service \
        && "${user_command[@]}" is-active --quiet aos-update-checker.service; then
        echo "Update checker started for $user."
        started=$((started + 1))
    else
        echo "Packages installed, but the checker could not be started for $user." >&2
        failed=1
    fi
done <<< "$users"
if [[ $started == 0 && $failed == 0 ]]; then
    echo 'No active user bus found: the checker will start at the next desktop login.'
fi
exit "$failed"
